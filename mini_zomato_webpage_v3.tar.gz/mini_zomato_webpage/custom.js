function myFunction1() {
    document.getElementById("dropa").classList.toggle("show");
}

window.onclick = function(event) {
  if (!(event.target.matches('.menu1')|| $(event.target).closest('#dropa').length != 0 )) {
   var dropdowns1 = document.getElementsByClassName("dropdown-content1");
    var i;
    for (i = 0; i < dropdowns1.length; i++) {
      var openDropdown1 = dropdowns1[i];
      if (openDropdown1.classList.contains('show')) {
       openDropdown1.classList.remove('show');
      }
    }
  }
 if (!(event.target.matches('.menu4')|| $(event.target).closest('#dropd').length != 0 )) {
   var dropdowns4 = document.getElementsByClassName("dropdown-content4");
    var l;
    for (l = 0; l < dropdowns4.length; l++) {
      var openDropdown4 = dropdowns4[l];
      if (openDropdown4.classList.contains('show')) {
       openDropdown4.classList.remove('show');
      }
    }
  }
 if (!(event.target.matches('.menu3')||$(event.target).closest('#dropc').length != 0)) {
   var dropdowns3 = document.getElementsByClassName("dropdown-content3");
    var k;
    for (k = 0; k < dropdowns3.length; k++) {
      var openDropdown3 = dropdowns3[k];
      if (openDropdown3.classList.contains('show')) {
       openDropdown3.classList.remove('show');
      }
    }
  }
 if (!(event.target.matches('.menu2')||$(event.target).closest('#dropb').length != 0)) {
   var dropdowns2 = document.getElementsByClassName("dropdown-content2");
    var j;
    for (j = 0; j < dropdowns2.length; j++) {
      var openDropdown2 = dropdowns2[j];
      if (openDropdown2.classList.contains('show')) {
       openDropdown2.classList.remove('show');
      }
    }
  }
 
}

function myFunction2() {
    document.getElementById("dropb").classList.toggle("show");
}

function myFunction3() {
    document.getElementById("dropc").classList.toggle("show");
}


function myFunction4() {
    document.getElementById("dropd").classList.toggle("show");
}
